const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const rotas = require('./routes');

app.use(express.json()); // Middleware para interpretar o corpo da requisição como JSON

app.use('/api', rotas); // Prefixo '/api' para todas as rotas

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
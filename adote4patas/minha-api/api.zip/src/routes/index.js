
const express = require('express');
const router = express.Router();

router.get('/usuarios', (req, res) => {
  res.json([
    { id: 1, nome: 'Usuário 1' },
    { id: 2, nome: 'Usuário 2' },
  ]);
});

router.post('/usuarios', (req, res) => {
  // Lógica para criar um novo usuário
  res.status(201).send('Usuário criado com sucesso!');
});

module.exports = router;